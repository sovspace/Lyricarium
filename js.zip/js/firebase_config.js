

export default {

    "apiKey": "AIzaSyA0snHj3cc-ygcWThJgleIi0i0cxlJ3oyI",
    "authDomain": "lyricarium.firebaseapp.com",
    "projectId": "lyricarium",
    "storageBucket": "lyricarium.appspot.com",
    "messagingSenderId": "618831067063",
    "appId": "1:618831067063:web:2c51e5170ca4f4a6cf1a32",
    "measurementId": "G-2BHW0E4VPW"

}