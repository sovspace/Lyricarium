export class Slide {

    constructor(title, htmlContent, styleNames) {
        this.title = title;
        this.htmlContent = htmlContent;
        this.styleNames = styleNames;
    }

}